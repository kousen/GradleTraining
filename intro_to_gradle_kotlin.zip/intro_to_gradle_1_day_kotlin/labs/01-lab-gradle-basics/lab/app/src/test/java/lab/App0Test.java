package lab;

import org.junit.Test;
import static org.junit.Assert.*;

public class App0Test {
    @Test public void testAppHasAGreeting() throws Exception {
        Thread.sleep(3500);
        App classUnderTest = new App();
        assertNotNull("app should have a greeting", classUnderTest.getGreeting());
    }
}
